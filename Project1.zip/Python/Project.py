def gettinginput(path):
    with open(path, 'r') as input:
        dimensions = input.readline().split(',')
        agent_position = input.readline().split(',')
        row = int(dimensions[0])
        column = int(dimensions[1])
        maze1 = input.readlines()
    return [row, column, maze1, agent_position[0], agent_position[1]]


file = gettinginput('test1.txt')
moves = 0
eatFood = False
action = ''
history = []
maze2 = []
for i in range(file[0]):
    row = []
    for j in range(file[1]):
        if i == 0 or j == 0 or i == file[0] - 1 or j == file[1] - 1:
            row.append('*')
        else:
            row.append('?')
    maze2.append(row)
agent_r = int(file[3])
agent_c = int(file[4])
percept = [agent_r, agent_c, eatFood]


def environment(action):
    global agent_r, agent_c, percept, eatFood, history, moves
    print("[{}, {}] -- {} -->".format(percept[0], percept[1], action), end=" ")
    match action:
        case 'Up':
            agent_r = agent_r - 1
        case 'Right':
            agent_c = agent_c + 1
        case 'Down':
            agent_r = agent_r + 1
        case 'Left':
            agent_c = agent_c - 1
    if file[2][agent_r][agent_c] == 'f':
        eatFood = True
    percept = [agent_r, agent_c, eatFood]
    maze2[agent_r][agent_c] = file[2][agent_r][agent_c]
    moves = moves + 1
    return percept


def agent(percept):
    global action, history
    if not maze2[percept[0]][percept[1]] == '*':
        if maze2[percept[0] + 1][percept[1]] == '?':
            action = 'Down'
            history.append(action)
            return action
        elif maze2[percept[0] - 1][percept[1]] == '?':
            action = 'Up'
            history.append(action)
            return action
        elif maze2[percept[0]][percept[1] + 1] == '?':
            action = 'Right'
            history.append(action)
            return action
        elif maze2[percept[0]][percept[1] - 1] == '?':
            action = 'Left'
            history.append(action)
            return action
        else:
            if len(history) == 0:
                return None
            ac = history.pop()
            match ac:
                case 'Up':
                    ac = 'Down'
                case 'Right':
                    ac = 'Left'
                case 'Down':
                    ac = 'Up'
                case 'Left':
                    ac = 'Right'
            return ac
    else:
        match action:
            case 'Up':
                action = 'Down'
            case 'Right':
                action = 'Left'
            case 'Down':
                action = 'Up'
            case 'Left':
                action = 'Right'
        history.pop()
        return action


act = agent(percept)
while not percept[2] and act is not None:
    environment(act)
    act = agent(percept)

if act is not None:
    print(f"[{percept[0]},{percept[1]}] Eat food")

print(f"How many moves: {moves}")
for row in maze2:
    print(row)